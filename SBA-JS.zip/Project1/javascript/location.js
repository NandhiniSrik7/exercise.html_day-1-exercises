var addr=[
    {
    "location":"Shrewsbury",
    "addr1":"50 main st",
    "zip":"01545",
    "open":"7:00 am",
    "close":"9:30 pm",
    "phone":"456 678 6890"
},
{
    "location":"Framingham",
    "addr1":"church st",
    "zip":"01748",
    "open":"7:00 am",
    "close":"9:30 pm",
    "phone":"785 568 7970"
},
{
"location":"Littleton",
"addr1":"Floral st",
"zip":"01845",
"open":"7:00 am",
"close":"9:30 pm",
"phone":"853 680 6790"
},
{
    "location":"Northborough",
"addr1":"Connecticut dr",
"zip":"01789",
"open":"7:00 am",
"close":"9:30 pm",
"phone":"895 567 5890"
},
{
    "location":"Worcester",
"addr1":"Connecticut dr",
"zip":"01789",
"open":"7:00 am",
"close":"9:30 pm",
"phone":"689 436 3680"
}
];

function getAddress(){
    console.log("inside me");
    var loc=document.getElementById("address").value;
    for(var i in addr){
       var obj=addr[i];
       
       //console.log(obj);
       for(var x in obj){
          if(loc===obj[x]){
               
              
                var paraVal="<img src='../images/location.jpg' width='25%' height='40%'/><br/>"+obj.addr1
                +"<br/>"+obj.location 
                +"<br/>"+obj.zip
                +"<br/>Opening time:"+obj.open
                +"<br/>Closing time:"+obj.close
                +"<br/>Phone :"+obj.phone;          
                var para = document.createElement('p');
                var divElement = document.querySelector("#main");
                para.innerHTML=  paraVal ; 
                divElement.appendChild(para);  

           }else{
               console.log("Not a location");
           }
       }
    }
}