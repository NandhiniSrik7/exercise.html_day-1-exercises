
console.log("Menu js");

var addItems = document.getElementById('addItems');
var grandTotal = 0;
addItems.addEventListener('click',addItemsToCart);

function addItemsToCart() {
    let getTable = document.getElementsByClassName('itemDetails');
    var para = "";
    
    
    
    //document.write(getTable.length)
    var rowlength = getTable.length;
    
    for (let i = 0; i < rowlength; i++) {
       
       
        let itemName = getTable[i].children[0].querySelector('input.itemName').value;
        let sugars = getTable[i].children[4].querySelector('input.numOfSugar').value;
        let qty = getTable[i].children[6].querySelector('input.quantity').value;
        let price = getTable[i].children[2].querySelector('input.price').value;

        console.log(itemName);
        console.log(sugars);
        console.log(qty);
        console.log(price);
        var amt = parseInt(qty) * parseInt(price);
        if (qty != 0) {
            hasOrder=true;
            para =  itemName + ":" + qty + ":" + "Total Amount " + ": $" + amt + "<br/>";
            grandTotal += amt;
           
            showDetails(para);

        }

       
        
    }
    addGrandTotaltoElement();    
}


    function showDetails(para) {
        let divElement = document.querySelector('.orderList');
        let newPara = document.createElement('p');
        newPara.innerHTML = para;
        newPara.style.color = 'rgb(85, 21, 21)';
        newPara.style.display = 'flex';
        newPara.style.justifyContent = 'center';
        divElement.appendChild(newPara);
        return true;
    }
    function addGrandTotaltoElement(){
      
            
           
            let divElement1 = document.querySelector('.orderList');
            let newPara1 = document.createElement('p');
            newPara1.innerHTML = "<br/>Grand Total : $" + grandTotal;
            divElement1.appendChild(newPara1);
            return false;
            
    }
   
  function validateNum(){
      var qty=document.querySelector('.quantity');
       var regex=/[0-9]/;
       var isNum =regex.exec(qty.value);
       if(!isNum){
        alert('Please enter valid number for Quantity');
        qty.value="";
        qty.focus();
        return false;
        
       }
       else {return true;};
  }
  function validateSugars(){
    var sugars=document.querySelector('.numOfSugar');
     var regex=/[0-9]/;
     var isNum =regex.exec(sugars.value);
     if(!isNum){
      alert('Please enter valid number for Sugars');
      sugars.value="";
      sugars.focus();
     }
}

