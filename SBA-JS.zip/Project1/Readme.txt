Project for a coffee shop


Index.html
* Followed grid system
* Used Images and videos
* Used external Js
* Used internal and external css
Menu.html
* Used tables
* Used arrays in Javascript
* Used Regex for number validation
* Used loops and conditional statements, functional call backs and events
Location.html
* Used drop down menu
* Used object collections 
* Used inline, external and Dom style Manipulations

